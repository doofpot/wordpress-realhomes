<?php
/**
 * Template Name: Home
 *
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/home/home' );
