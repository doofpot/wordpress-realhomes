<?php
/**
 * Template Name: 2 Columns Gallery
 *
 * @since   1.0.0
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/page/2-columns-gallery' );
