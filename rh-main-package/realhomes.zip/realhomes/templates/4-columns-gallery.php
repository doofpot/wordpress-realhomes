<?php
/**
 * Template Name: 4 Columns Gallery
 *
 * @since   1.0.0
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/page/4-columns-gallery' );
