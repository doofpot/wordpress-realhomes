<?php
/**
 * Taxonomy: Property Feature
 *
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/taxonomy/property-feature' );
