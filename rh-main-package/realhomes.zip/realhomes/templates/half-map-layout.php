<?php
/**
 * Template Name: Properties with Half Map
 *
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/page/properties-with-map' );
