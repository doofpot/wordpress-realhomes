<?php
/**
 * Template Name: Property Full Width
 * Template Post Type: property
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/property/single-fullwidth' );