<?php
/**
 * Template Name: Properties Grid Full Width
 *
 * Display properties in grid layout full width.
 *
 * @since 3.7.1
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/page/properties-grid-full-width' );