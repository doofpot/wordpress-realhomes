<?php
/**
 * Template Name: Optima Express Template
 *
 * @since   2.6.3
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/page/optima-express' );
