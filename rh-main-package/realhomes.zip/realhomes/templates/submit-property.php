<?php
/**
 * Template Name: Submit Property
 *
 * @since   1.0.0
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/page/submit-property' );
