<?php
/**
 * Template Name: Post Full Width
 * Template Post Type: Post
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/blog/single-fullwidth' );