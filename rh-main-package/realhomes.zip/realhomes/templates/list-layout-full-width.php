<?php
/**
 * Template Name: Properties List Full Width
 *
 * Display properties in List layout full width.
 *
 * @since 3.7.1
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/page/properties-list-full-width' );

