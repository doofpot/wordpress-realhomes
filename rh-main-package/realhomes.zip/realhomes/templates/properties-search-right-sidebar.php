<?php
/**
 * Template Name: Properties Search Right Sidebar
 *
 * @since   1.0.0
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/page/search-right-sidebar' );
