<?php
/**
 * Template Name: Edit Profile
 *
 * Allow users to update their profile information from front end.
 *
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/page/edit-profile' );
