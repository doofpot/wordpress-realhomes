/*-----------------------------------------------------------------------------------*/
/*	Admin side JS
 /*-----------------------------------------------------------------------------------*/
jQuery(document).ready(function() {

    /* Disable Parent Select */
    jQuery("#newproperty-feature_parent").remove();
    jQuery("#newproperty-status_parent").remove();

});